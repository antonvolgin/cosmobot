from .logger import logger_setup, logger_debug

logger_setup(f"cosmo")
logger_debug(f"init: app...")
